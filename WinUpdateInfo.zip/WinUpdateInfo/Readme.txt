Rus
Что бы включить программу зайдите в Debug или Release потом выберите x64 или x86 (если у вас 64 битная версия виндовс выберите x64 если 32 битная выберите x86) потом запустите на программу WinUpdateInfo (Запускайте от имени админа что бы точно все работало).
Usa
To enable the program, go to Debug or Release, then select x64 or x86 (if you have a 64-bit version of Windows, select x64, if 32-bit, select x86) then run the WinUpdateInfo program (Run as administrator to make sure everything works).